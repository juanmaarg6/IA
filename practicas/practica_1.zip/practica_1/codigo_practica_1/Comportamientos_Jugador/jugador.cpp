#include "../Comportamientos_Jugador/jugador.hpp"
#include <iostream>

#include <vector>
#include <stdlib.h>

using namespace std;

Action ComportamientoJugador::think(Sensores sensores) {

	Action accion = actIDLE;



	/***********************************************************/
	/********* ACTUALIZACIÓN DE LAS VARIABLES DE ESTADO ********/
	/***********************************************************/

	switch (ultimaAccion){
		case actFORWARD:
			if(!sensores.colision)
				switch (brujula){
					case 0: // Norte
						fil--; 
					break;

					case 1: // Este
						col++; 
					break;

					case 2: // Sur
						fil++; 
					break;

					case 3: // Oeste
						col--; 
					break;
				}
		break;

		case actTURN_L:
			brujula = (brujula + 3) % 4;

			if(rand() % 2 == 0)
				girar_derecha = true;
			else
				girar_derecha = false;
		break;

		case actTURN_R:
			brujula = (brujula + 1) % 4;

			if(rand() % 2 == 0)
				girar_derecha = true;
			else
				girar_derecha = false;
		break;
	}

	// Si pisamos una casilla de bikini, pasamos a tener bikini
	if(sensores.terreno[0] == 'K' && !tengo_bikini)
		tengo_bikini = true;

	// Si pisamos una casilla de zapatillas, pasamos a tener zapatillas
	if(sensores.terreno[0] == 'D' && !tengo_zapatillas)
		tengo_zapatillas = true;

	// Si estoy en el nivel 0 o en el nivel 1, el sensor de orientación funciona
	if(sensores.nivel <= 1)
		brujula = sensores.sentido;

	// Si estoy en el nivel 0, todo el sistema sensorial funciona
	if(sensores.nivel == 0) {
		fil = sensores.posF;
		col = sensores.posC;
		bien_situado = true;
	}

	// Si muero, todas las variables se reinician a su valor inicial
	if(sensores.reset) {
		reiniciar();
	}

	// Si estamos en el nivel 1 o superior, no estamos bien situados.
	// Luego, al pisar una casilla de posicionamiento, pasan a 
	// funcionar los sensores de posición
	if(sensores.terreno[0] == 'G' && !bien_situado) {
		int df = fil - sensores.posF;
		int dc = col - sensores.posC;
		fil = sensores.posF;
		col = sensores.posC;

		trasladarMapaAuxiliar(df, dc);

		bien_situado = true;
	}



	/***********************************************************/
	/************ DETERMINAR CONJUNTO DE MOVIMIENTOS ***********/
	/***********************************************************/

	if( movimientos.empty() ) {

		if( situacionIncontrolable(sensores) && !sePuedeEscapar(sensores) )
			movimientos.push_back(actFORWARD);
		else if( hayMapaPorDescubrir() && puedeAvanzar(sensores) )
			movimientos.push_back(actFORWARD);
		else if( sensores.terreno[1] == 'M' || sensores.terreno[2] == 'M'  || sensores.terreno[3] == 'M' || sensores.terreno[5] == 'M' || sensores.terreno[7] == 'M')
			rodearMuros(sensores);
		else if(sensores.terreno[1] == 'P' || sensores.terreno[2] == 'P'  || sensores.terreno[3] == 'P' || sensores.terreno[5] == 'P' || 
		        sensores.terreno[7] == 'P' || sensores.terreno[11] == 'P' || sensores.terreno[13] == 'P')
			evitarPrecipicios(sensores);
		else if( !bien_situado || !tengo_bikini || !tengo_zapatillas || sensores.terreno[0] == 'A' || sensores.terreno[0] == 'B' || sensores.bateria <= 4000 )
			irParaCiertaCasilla(sensores);
	}



	/***********************************************************/
	/***************** ELEGIR ACCIÓN A REALIZAR ****************/
	/***********************************************************/

	// Cada 5 giros, la acción será por avanzar (esto es por si se queda quieto girando en una casilla)
	if( atascadoEnUnaCasilla(sensores) ) {
		accion = actFORWARD;
	}
	// Si tenemos un conjunto de movimientos pendientes, los realizamos
	else if( !movimientos.empty() ) {

		if( !situacionIncontrolable(sensores) && (movimientos.at(0) == actFORWARD) && (sensores.terreno[2] == 'P' || (sensores.terreno[2] == 'A' && !tengo_bikini) || (sensores.terreno[2] == 'B' && !tengo_zapatillas) ) ) {
			int num_aleatorio = rand()%2;

			if(num_aleatorio == 0)
				accion = actTURN_R;
			else
				accion = actTURN_L;
			movimientos.clear();
		}
		else {
			accion = movimientos.at(0);
			movimientos.erase( movimientos.begin() );
		}

	}
	else if( hayAldeano(sensores) ) {
		if(sensores.superficie[2] != 'a')
			accion = actFORWARD;
		else {
			int num_aleatorio = rand()%2;

			if(num_aleatorio == 0)
				accion = actTURN_R;
			else if (num_aleatorio == 1)
				accion = actTURN_L;
		}
	}
	else if( hayLobo(sensores) ) {
		if(sensores.superficie[1] == 'l' || sensores.superficie[5] == 'l' || sensores.superficie[11] == 'l')
			accion = actTURN_R;
		else if(sensores.superficie[3] == 'l' || sensores.superficie[7] == 'l' || sensores.superficie[13] == 'l')
			accion = actTURN_L;
		else if(sensores.superficie[4] == 'l' || sensores.superficie[8] == 'l' || sensores.superficie[9] == 'l' || sensores.superficie[10] == 'l' || sensores.superficie[14] == 'l' || sensores.superficie[15] == 'l')
			accion = actFORWARD;
		else
			accion = actIDLE;
	}
	// Si estamos en una casilla de recarga, no hacemos nada hasta recargar lo suficiente
	else if( estoyRecargando(sensores) ) {
		accion = actIDLE;
	}
	// Si tenemos delante una casilla por la que podamos avanzar,
	// elegimos aleatoriamente si giramos o avanzamos (dándole más probabilidad a avanzar)
	else if (puedeAvanzar(sensores) ) {

		int num_aleatorio = rand()%30;

		if(num_aleatorio == 0)
			accion = actTURN_R;
		else if (num_aleatorio == 5)
			accion = actTURN_L;
		else {
			accion = actFORWARD;
		}
	}
	// Si tenemos delante bosque o agua y no tenemos zapatillas o bikini, respectivamente,
	// elegimos aleatoriamente si giramos hacia la derecha o hacia la izquierda (nunca avanzamos) 
	else if( situacionNoIdonea(sensores) ) {
		int num_aleatorio = rand()%2;

		if(num_aleatorio == 0)
			accion = actTURN_R;
		else
			accion = actTURN_L;
	}
	// Si no se da ninguna de las situaciones anteriores, elegimos aleatoriamente
	// si giramos hacia la derecha o hacia la izquierda
	else {
		accion = girar();
	}



	/***********************************************************/
	/********************** RELLENAR MAPA **********************/
	/***********************************************************/

	// Si estamos bien situado, dibujamos el mapa a medida que lo recorremos
	if(bien_situado)
		dibujarMapaResultado(sensores);
	// Si no estamos bien situado, almacenamos lo que vamos viendo a medida
	// que lo recorremos en un mapa auxiliar
	else
		guardarMapaAuxiliar(sensores);

	if(sensores.bateria <= 200 || sensores.vida <= 30)
		inferirMapa();




	/***********************************************************/
	/*** DETERMINAR EL EFECTO DE LA ÚLTIMA ACCIÓN REALIZADA ****/
	/***********************************************************/

	ultimaAccion = accion;

	return accion;
}

int ComportamientoJugador::interact(Action accion, int valor){
  return false;
}



/***********************************************************/
/****************** FUNCIONES AUXILIARES *******************/
/***********************************************************/

bool ComportamientoJugador::estoyRecargando(Sensores sensores) {
	return (sensores.terreno[0]=='X' && sensores.bateria < 4000);
}

bool ComportamientoJugador::situacionIncontrolable(Sensores sensores) {
	return ( (sensores.terreno[0]=='B' && !tengo_zapatillas) || 
			 (sensores.terreno[0]=='A' && !tengo_bikini) || 
			 (sensores.terreno[2]=='B' && !tengo_zapatillas && sensores.vida >= 2990) || 
			 (sensores.terreno[2]=='A' && !tengo_bikini && sensores.vida >= 2990)
			);
}

bool ComportamientoJugador::situacionNoIdonea(Sensores sensores) {
	return ( (sensores.terreno[2]=='B' && !tengo_zapatillas) || 
			 (sensores.terreno[2]=='A' && !tengo_bikini)
			);
}

void ComportamientoJugador::dibujarMapaResultado(Sensores sensores) {

	int i = 0;

	switch(brujula) {
		case 0:
			for(int j = 0; j <= 3; j++)
				for(int k = -j; k <= j; k++) {
					mapaResultado[fil - j][col + k] = sensores.terreno[i];
					i++;
				}
		break;

		case 1:
			for(int j = 0; j <= 3; j++)
				for(int k = -j; k <= j; k++) {
					mapaResultado[fil + k][col + j] = sensores.terreno[i];
					i++;
				}
		break;

		case 2:
			for(int j = 0; j <= 3; j++)
				for(int k = -j; k <= j; k++) {
					mapaResultado[fil + j][col - k] = sensores.terreno[i];
					i++;
				}
		break;

		case 3:
			for(int j = 0; j <= 3; j++)
				for(int k = -j; k <= j; k++) {
					mapaResultado[fil - k][col - j] = sensores.terreno[i];
					i++;
				}
		break;
	}
}

void ComportamientoJugador::guardarMapaAuxiliar(Sensores sensores) {

	int i = 0;

	switch(brujula) {
		case 0:
			for(int j = 0; j <= 3; j++)
				for(int k = -j; k <= j; k++) {
					mapaAuxiliar[fil - j][col + k] = sensores.terreno[i];
					i++;
				}
		break;

		case 1:
			for(int j = 0; j <= 3; j++)
				for(int k = -j; k <= j; k++) {
					mapaAuxiliar[fil + k][col + j] = sensores.terreno[i];
					i++;
				}
		break;

		case 2:
			for(int j = 0; j <= 3; j++)
				for(int k = -j; k <= j; k++) {
					mapaAuxiliar[fil + j][col - k] = sensores.terreno[i];
					i++;
				}
		break;

		case 3:
			for(int j = 0; j <= 3; j++)
				for(int k = -j; k <= j; k++) {
					mapaAuxiliar[fil - k][col - j] = sensores.terreno[i];
					i++;
				}
		break;
	}
}

void ComportamientoJugador::trasladarMapaAuxiliar(int df, int dc) {

	for (int i = 0; i < mapaResultado.size(); ++i)
		for (int j = 0; j < mapaResultado.size(); ++j)
			if(mapaResultado[i][j] == '?')
				mapaResultado[i][j] = mapaAuxiliar[df + i][dc + j];
}

bool ComportamientoJugador::puedeAvanzar(Sensores sensores) {
	return ( (sensores.terreno[2] == 'T' || 
			  sensores.terreno[2] == 'S' || 
			  (sensores.terreno[2] == 'B' && tengo_zapatillas) || 
			  (sensores.terreno[2] == 'A'  && tengo_bikini) || 
			  sensores.terreno[2] == 'D' || 
			  sensores.terreno[2] == 'K' ||
			  sensores.terreno[2] == 'X' || 
			  sensores.terreno[2] == 'G' 
			  ) 
			  && 
			  (sensores.superficie[2] == '_')
			  && 
			  (sensores.terreno[2] != 'P') 
			  &&
			  (sensores.terreno[2] != 'M') 
			);
}

bool ComportamientoJugador::sePuedeEscapar(Sensores sensores) {
	bool se_puede_escapar = false;

	if( (sensores.terreno[0] == 'B' || sensores.terreno[0] == 'A') && sensores.terreno[2] == 'P')
		se_puede_escapar = true;
	else if(sensores.terreno[0] == 'B')
		for(int i = 0; i <= 15 && !se_puede_escapar; ++i)
			if(sensores.terreno[i] != 'B')
				se_puede_escapar = true;
	else if(sensores.terreno[0] == 'A' )
		for(int i = 0; i <= 15 && !se_puede_escapar; ++i)
			if(sensores.terreno[i] != 'A')
				se_puede_escapar = true;

	return se_puede_escapar;
}

bool ComportamientoJugador::hayMapaPorDescubrir() {
	bool hay_mapa_por_descubrir = false;

	if(bien_situado)
		switch(brujula) {
			case 0:
				for(int i = -3; i<=3 && !hay_mapa_por_descubrir; ++i)
					if(fil-4 >= 0)
						if(mapaResultado[fil-4][col+i]=='?')
							hay_mapa_por_descubrir = true;
			break;

			case 1:
				for(int i = -3; i<=3 && !hay_mapa_por_descubrir; ++i)
					if( col+4 < mapaResultado.size() )
						if(mapaResultado[fil+i][col+4]=='?')
							hay_mapa_por_descubrir = true;
			break;

			case 2:
				for(int i = -3; i<=3 && !hay_mapa_por_descubrir; ++i)
					if( fil+4 < mapaResultado.size() )
						if(mapaResultado[fil+4][col+i]=='?')
							hay_mapa_por_descubrir = true;
			break;

			case 3:
				for(int i = -3; i<=3 && !hay_mapa_por_descubrir; ++i)
					if(col-4 >= 0)
						if(mapaResultado[fil+i][col-4]=='?')
							hay_mapa_por_descubrir = true;
			break;
		}

	return hay_mapa_por_descubrir;
}

void ComportamientoJugador::reiniciar(){
	brujula = 0;
	fil = 99;
	col = 99;
	bien_situado = false;
	ultimaAccion = actIDLE;
	girar_derecha = false;
    tengo_bikini = false;
	tengo_zapatillas = false;
	num_giros_consecutivos = 0;

	movimientos.clear();

	for (int i = 0; i < 200; ++i)
		for (int j = 0; j < 200; ++j)
				mapaAuxiliar[i][j] = '?';
}

Action ComportamientoJugador::girar(){
	Action accion;

	if(!girar_derecha){
		accion = actTURN_L;

		girar_derecha = (rand() % 2 == 0);
	}
	else{
		accion = actTURN_R;
		girar_derecha = (rand() % 2 == 0);
	}

	return accion;
}

void ComportamientoJugador::rodearMuros(Sensores sensores) {
	if(sensores.terreno[2] == 'M') {
		if(sensores.terreno[1] == 'P' && sensores.terreno[3] != 'P') {
			movimientos.push_back(actTURN_R);
			movimientos.push_back(actFORWARD);
		}
		else if(sensores.terreno[3] == 'P' && sensores.terreno[1] != 'P') {
			movimientos.push_back(actTURN_L);
			movimientos.push_back(actFORWARD);
		}
		else {
			int num_aleatorio = rand()%2;

			if(num_aleatorio == 0)
				movimientos.push_back(actTURN_R);
			else
				movimientos.push_back(actTURN_L);
		}
	}
	else if(sensores.terreno[1] == 'M' && sensores.terreno[3] == 'M') {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_L);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);

	}
	else if( (sensores.terreno[4] == 'M' && sensores.terreno[5] != 'M' && sensores.terreno[5] != 'P' && sensores.terreno[6] == 'M') ||
	         (sensores.terreno[4] != 'M' && sensores.terreno[4] != 'P' && sensores.terreno[5] != 'M' && sensores.terreno[6] == 'M') ) {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_L);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_R);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
	}
	else if( (sensores.terreno[5] == 'M' && sensores.terreno[6] != 'M' && sensores.terreno[6] != 'P' && sensores.terreno[7] == 'M') ||
			 (sensores.terreno[4] == 'M' && sensores.terreno[5] != 'M' && sensores.terreno[6] != 'M' && sensores.terreno[6] != 'P'  && sensores.terreno[7] == 'M') ||
			 (sensores.terreno[5] == 'M' && sensores.terreno[6] != 'M' && sensores.terreno[6] != 'P' && sensores.terreno[7] != 'M' && sensores.terreno[8] == 'M') ) {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
	}
	else if( (sensores.terreno[6] == 'M' && sensores.terreno[7] != 'M' && sensores.terreno[7] != 'P' && sensores.terreno[8] == 'M') ||
			 (sensores.terreno[6] == 'M' && sensores.terreno[7] != 'M' && sensores.terreno[7] != 'P' && sensores.terreno[8] != 'M' ) ) {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_R);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_L);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
	}
	else if( (sensores.terreno[1] == 'M' && sensores.terreno[5] == 'M') || (sensores.terreno[3] == 'M' && sensores.terreno[7] == 'M') &&
			  !(sensores.terreno[2] == 'B' && !tengo_zapatillas) && !(sensores.terreno[2] == 'A' && !tengo_bikini) ) {
		int num_aleatorio = rand()%20;

		if(num_aleatorio == 0)
			movimientos.push_back(actTURN_R);
		else if(num_aleatorio == 10)
			movimientos.push_back(actTURN_L);
		else 
			movimientos.push_back(actFORWARD);
	}
	else if(sensores.terreno[1] != 'M' && sensores.terreno[1] != 'P' && sensores.terreno[5] == 'M' && sensores.terreno[4] != 'M') {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_L);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_L);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
	}
	else if(sensores.terreno[3] != 'M' && sensores.terreno[3] != 'P'  && sensores.terreno[7] == 'M' && sensores.terreno[8] != 'M') {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_R);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_L);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
	}
	else if(sensores.terreno[1] == 'M' && sensores.terreno[5] != 'M') {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_L);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
	}
	else if(sensores.terreno[3] == 'M' && sensores.terreno[7] != 'M') {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_R);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
	}
}


void ComportamientoJugador::evitarPrecipicios(Sensores sensores) {

	if(sensores.terreno[2] == 'P') {
		if(sensores.terreno[1] == 'P' && sensores.terreno[3] != 'P') {
			movimientos.push_back(actTURN_R);
			movimientos.push_back(actFORWARD);
			movimientos.push_back(actTURN_L);
			movimientos.push_back(actFORWARD);
		}
		else if(sensores.terreno[3] == 'P' && sensores.terreno[1] != 'P') {
			movimientos.push_back(actTURN_L);
			movimientos.push_back(actFORWARD);
			movimientos.push_back(actTURN_R);
			movimientos.push_back(actFORWARD);
		}
		else if(sensores.terreno[3] == 'P' && sensores.terreno[1] == 'P') {

			movimientos.push_back(actTURN_R);
			movimientos.push_back(actTURN_R);
			movimientos.push_back(actFORWARD);
			movimientos.push_back(actFORWARD);

			int num_aleatorio = rand()%2;

			if(num_aleatorio == 0)
				movimientos.push_back(actTURN_R);
			else
				movimientos.push_back(actTURN_L);
		}
	}
	else if( (sensores.terreno[1] == 'P' && sensores.terreno[5] == 'P') || (sensores.terreno[3] == 'P' && sensores.terreno[7] == 'P') ||
	 		 (sensores.terreno[1] != 'P' && sensores.terreno[2] != 'P') || (sensores.terreno[2] != 'P' && sensores.terreno[3] != 'P') ) {
		movimientos.push_back(actFORWARD);
	}
	else if ( (sensores.terreno[3] == 'P' && sensores.terreno[13] == 'P' && sensores.terreno[7] != 'P') ||
			  (sensores.terreno[3] != 'P' && sensores.terreno[13] == 'P' && sensores.terreno[7] != 'P') ||
			  (sensores.terreno[3] == 'P' && sensores.terreno[13] != 'P' && sensores.terreno[7] != 'P') ) {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_R);
		movimientos.push_back(actFORWARD);
	}
	else if ( (sensores.terreno[1] == 'P' && sensores.terreno[11] == 'P' && sensores.terreno[5] != 'P') ||
			  (sensores.terreno[1] != 'P' && sensores.terreno[11] == 'P' && sensores.terreno[5] != 'P') ||
			  (sensores.terreno[1] == 'P' && sensores.terreno[11] != 'P' && sensores.terreno[5] != 'P') ) {
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actFORWARD);
		movimientos.push_back(actTURN_L);
		movimientos.push_back(actFORWARD);
	}
}

void ComportamientoJugador::irParaCiertaCasilla(Sensores sensores) {

	bool hay_casilla = false;
	int i = 0;

	while(i <= 15 && !hay_casilla) {

		i++;

		if( movimientos.empty() && 
			( (sensores.terreno[i] == 'G' && !bien_situado) || 
			(sensores.terreno[i] == 'K' && !tengo_bikini) || 
			(sensores.terreno[0] =='A' && sensores.terreno[i] != 'A' && !tengo_bikini && (sensores.terreno[i] != 'B' || (sensores.terreno[i] == 'B' && tengo_zapatillas))) || 
			(sensores.terreno[0] =='B' && sensores.terreno[i] != 'B' && !tengo_zapatillas && (sensores.terreno[i] != 'A' || (sensores.terreno[i] == 'A' && tengo_bikini))) || 
			(sensores.terreno[i] == 'D' && !tengo_zapatillas) || 
			(sensores.terreno[i] == 'X' && sensores.bateria <= 4000) 
			)
		   ) {
			hay_casilla = true;
		}
	}
	
	if( hay_casilla && movimientos.empty() )
		switch(i) {
			case 1:
				movimientos.push_back(actFORWARD) ; 
				movimientos.push_back(actTURN_L) ; 
				movimientos.push_back(actFORWARD) ;
			break;

			case 2:
				movimientos.push_back(actFORWARD) ;
			break;

			case 3:
				movimientos.push_back(actFORWARD) ; 
				movimientos.push_back(actTURN_R) ; 
				movimientos.push_back(actFORWARD) ;
			break;

			case 4:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; 
				movimientos.push_back(actTURN_L) ; 
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
			break;

			case 5:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
				movimientos.push_back(actTURN_L) ; 
				movimientos.push_back(actFORWARD) ;
			break;

			case 6:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD);
			break;

			case 7:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; 
				movimientos.push_back(actTURN_R) ; 
				movimientos.push_back(actFORWARD) ;
			break;

			case 8:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
				movimientos.push_back(actTURN_R) ; 
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
			break;

			case 9:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
				movimientos.push_back(actTURN_L) ; 
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
			break;

			case 10:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
				movimientos.push_back(actTURN_L) ; 
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
			break;

			case 11:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
				movimientos.push_back(actTURN_L) ; 
				movimientos.push_back(actFORWARD) ;
			break;

			case 12:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
			break;

			case 13:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
				movimientos.push_back(actTURN_R) ; 
				movimientos.push_back(actFORWARD) ;
			break;

			case 14:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
				movimientos.push_back(actTURN_R) ; 
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
			break;

			case 15:
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
				movimientos.push_back(actTURN_R) ; 
				movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ; movimientos.push_back(actFORWARD) ;
			break;
		}
}

bool ComportamientoJugador::atascadoEnUnaCasilla(Sensores sensores) {
	if(ultimaAccion == actTURN_L || ultimaAccion == actTURN_R)
		num_giros_consecutivos++;
	else 
		num_giros_consecutivos = 0;

	return (num_giros_consecutivos == 5);
} 

bool ComportamientoJugador::hayAldeano(Sensores sensores) {
	bool hay_aldeano = false;

	for(int i=1; i<=15 && !hay_aldeano; ++i)
		if(sensores.superficie[i] == 'a')
			hay_aldeano = true;

	return hay_aldeano;
}

bool ComportamientoJugador::hayLobo(Sensores sensores) {
	bool hay_lobo = false;

	for(int i=1; i<=15 && !hay_lobo; ++i)
		if(sensores.superficie[i] == 'l')
			hay_lobo = true;

	return hay_lobo;

}

int ComportamientoJugador::contarCasillasSinDescubrir() {

	int num_casillas_sin_descubrir = 0;

	for(int i = 0; i < mapaResultado.size(); ++i)
		for(int j = 0; j < mapaResultado.size(); ++j)
			if(mapaResultado[i][j] == '?')
				num_casillas_sin_descubrir++;

	return num_casillas_sin_descubrir;
}

bool ComportamientoJugador::casillaAlrededorDescubierta(int f, int c) {

	bool casilla_alrededor_descubierta = false;

	for(int i = f-1; i <= f+1 && !casilla_alrededor_descubierta; ++i)
		for(int j = c-1; j <= c+1 && !casilla_alrededor_descubierta; ++j)
			if( i >= 0 && j >= 0 && i < mapaResultado.size() && j < mapaResultado.size() )
				if(mapaResultado[i][j] != '?')
					casilla_alrededor_descubierta = true;

	return casilla_alrededor_descubierta;
}

vector<pair<int,int>> ComportamientoJugador::obtenerCasillasSinDescubrir() {

	vector<pair<int,int>> v;

	for (int i = 0; i < mapaResultado.size(); ++i)
		for (int j = 0; j < mapaResultado.size(); ++j)
			if( mapaResultado[i][j] == '?' && casillaAlrededorDescubierta(i,j) ) {
				v.push_back( pair<int,int> (i,j) );
			}

	return v;
}

char ComportamientoJugador::casillaMasRepetida(int ini_f, int fin_f, int ini_c, int fin_c) {
	
	double porcentaje_mapa_sin_descubrir = contarCasillasSinDescubrir() * 100 / ( mapaResultado.size() * mapaResultado.size() );

	char tipo_casilla;

	int vector_casillas[10] = {0};

	if(porcentaje_mapa_sin_descubrir < 100.0) {
		for(int i = ini_f; i <= fin_f; ++i)
			for(int j = ini_c; j <= fin_c; ++j)
				if( i >= 0 && j >= 0 && i < mapaResultado.size() && j < mapaResultado.size() )
					switch( mapaResultado[i][j] ) {
						case 'B':
							vector_casillas[0]++;
						break;

						case 'A':
							vector_casillas[1]++;
						break;

						case 'P':
							vector_casillas[2]++;
						break;

						case 'S':
							vector_casillas[3]++;
						break;

						case 'T':
							vector_casillas[4]++;
						break;

						case 'M':
							vector_casillas[5]++;
						break;

						case 'K':
							vector_casillas[6]++;
						break;

						case 'D':
							vector_casillas[7]++;
						break;

						case 'X':
							vector_casillas[8]++;
						break;

						case 'G':
							vector_casillas[9]++;
						break;
					}
	}
	else {
		for(int i = ini_f; i <= fin_f; ++i)
			for(int j = ini_c; j <= fin_c; ++j)
				if( i >= 0 && j >= 0 && i < 200 && j < 200 ) // 200 es el tamaño de la matriz auxiliar
					switch( mapaAuxiliar[i][j] ) {
						case 'B':
							vector_casillas[0]++;
						break;

						case 'A':
							vector_casillas[1]++;
						break;

						case 'P':
							vector_casillas[2]++;
						break;

						case 'S':
							vector_casillas[3]++;
						break;

						case 'T':
							vector_casillas[4]++;
						break;

						case 'M':
							vector_casillas[5]++;
						break;

						case 'K':
							vector_casillas[6]++;
						break;

						case 'D':
							vector_casillas[7]++;
						break;

						case 'X':
							vector_casillas[8]++;
						break;

						case 'G':
							vector_casillas[9]++;
						break;
					}
	}

	int max = vector_casillas[0];
	int pos_max = 0;

	for(int i = 0; i < 10; ++i)
		if(max < vector_casillas[i]) {
			max = vector_casillas[i];
			pos_max = i;
		}

	switch(pos_max) {
		case 0:
			tipo_casilla = 'B';
		break;

		case 1:
			tipo_casilla = 'A';
		break;

		case 2:
			tipo_casilla = 'P';
		break;

		case 3:
			tipo_casilla = 'S';
		break;

		case 4:
			tipo_casilla = 'T';
		break;

		case 5:
			tipo_casilla = 'M';
		break;

		case 6:
			tipo_casilla = 'K';
		break;

		case 7:
			tipo_casilla = 'D';
		break;

		case 8:
			tipo_casilla = 'X';
		break;

		case 9:
			tipo_casilla = 'G';
		break;
	}

	return tipo_casilla;
}

void ComportamientoJugador::inferirMapaLocalmente() {

	vector<pair<int,int>> v = obtenerCasillasSinDescubrir();

	if( !v.empty() ) {

		for(int i = 0; i < v.size(); ++i) {
			int fila_casilla_sin_descubrir = v[i].first;
			int columna_casilla_sin_descubrir = v[i].second;

			mapaResultado[fila_casilla_sin_descubrir][columna_casilla_sin_descubrir] = casillaMasRepetida(fila_casilla_sin_descubrir-1, fila_casilla_sin_descubrir+1,
																								          columna_casilla_sin_descubrir-1, columna_casilla_sin_descubrir+1);
		}
	}
}

void ComportamientoJugador::inferirMapaGlobalmente() {

	double porcentaje_mapa_sin_descubrir = contarCasillasSinDescubrir() * 100 / ( mapaResultado.size() * mapaResultado.size() );

	char casilla_descubierta_mas_repetida;

	if(porcentaje_mapa_sin_descubrir < 100.0)
		casilla_descubierta_mas_repetida = casillaMasRepetida(0, mapaResultado.size()-1, 	// Miramos en mapaResultado
														      0, mapaResultado.size()-1);
	else
		casilla_descubierta_mas_repetida = casillaMasRepetida(0, 199, 						// Miramos en mapaAuxiliar
														      0, 199);
	
	for(int i = 0; i < mapaResultado.size(); ++i)
		for(int j = 0; j < mapaResultado.size(); ++j)
			if(mapaResultado[i][j] == '?')
				mapaResultado[i][j] = casilla_descubierta_mas_repetida;
}

void ComportamientoJugador::inferirMapa() {

	double porcentaje_mapa_sin_descubrir = contarCasillasSinDescubrir() * 100 / ( mapaResultado.size() * mapaResultado.size() );

	if(porcentaje_mapa_sin_descubrir <= 45.0)
		inferirMapaLocalmente();
	else
		inferirMapaGlobalmente();
}