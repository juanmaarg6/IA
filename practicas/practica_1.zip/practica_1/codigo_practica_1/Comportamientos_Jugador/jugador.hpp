#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"
#include <stdlib.h>

using namespace std;

class ComportamientoJugador : public Comportamiento{

  public:
    ComportamientoJugador(unsigned int size) : Comportamiento(size){
      // Constructor de la clase
      // Dar el valor inicial a las variables de estado
      fil = col = 99;
      brujula = 0;
      girar_derecha = false;
      bien_situado = false;
      tengo_bikini = false;
      tengo_zapatillas = false;
      num_giros_consecutivos = 0;
      ultimaAccion = actIDLE;

      // Mapa auxiliar
      for (int i = 0; i < 200; ++i){
        for (int j = 0; j < 200; ++j){
          mapaAuxiliar[i][j] = '?';
        }
      }
    }

    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}
    ~ComportamientoJugador(){}

    Action think(Sensores sensores);
    int interact(Action accion, int valor);

    /***********************************************************/
    /****************** FUNCIONES AUXILIARES *******************/
    /***********************************************************/

    /**
     * @brief Indica si el jugador se encuentra quieto en una casilla de recarga
     * @param sensores Sensores
     * @return True si el jugador está recargando y False si no lo está
     */
    bool estoyRecargando(Sensores sensores);

    /**
     * @brief Indica si el jugador justo aparece en una casilla de bosque o agua
     *        y no tiene zapatillas o bikini, respectivamente. También indica si
     *        el jugador tiene delante una casilla de bosque o agua, no tiene
     *        zapatillas o bikini, respectivamente, y, además, los ciclos son
     *        mayores a 2990 (esto nos permitirá avanzar por bosque o agua aunque
     *        no tengamos zapatillas o bikini, respectivamente, en los diez primeros
     *        ciclos)
     * @param sensores Sensores
     * @return True si el jugador está en una situación incontrolable
     *         y False si no lo está
     */
    bool situacionIncontrolable(Sensores sensores);

    /**
     * @brief Indica si el jugador tiene delante una casilla de bosque o agua
     *        y no tiene zapatillas o bikini, respectivamente
     * @param sensores Sensores
     * @return True si el jugador está en una situación no idónea
     *         y False si no lo está
     */
    bool situacionNoIdonea(Sensores sensores);

    /**
     * @brief Utilizando la información de los sensores, dibuja el mapa que
     *        se va descubriendo
     * @param sensores Sensores
     */
    void dibujarMapaResultado(Sensores sensores);

    /**
     * @brief Aunque no se esté bien situados, guarda la información del mapa que
     *        se va visitando en un mapa auxiliar
     * @param sensores Sensores
     */
    void guardarMapaAuxiliar(Sensores sensores);

    /**
     * @brief Cuando se esté bien situados, se traslada la información del mapa auxiliar
     *        al mapa resultado
     * @param df Diferencia de filas
     * @param dc Diferencia de columnas
     */
    void trasladarMapaAuxiliar(int df, int dc);

    /**
     * @brief Situaciones en las que el jugador puede avanzar una casilla
     * @param sensores Sensores
     * @return True si el jugador puede avanzar y False si no puede
     */
    bool puedeAvanzar(Sensores sensores);

    /**
     * @brief Indica si el jugador está en el bosque o en el agua sin zapatillas o bikini, 
     *        respectivamente, y ve una casilla diferente para salir de esa situación.
     * @param sensores Sensores
     * @return True si el jugador puede escapar y False si no puede
     */
    bool sePuedeEscapar(Sensores sensores);

    /**
     * @brief Indica si en la línea justo delante de los sensores del 9 al 15
     *        hay alguna casilla por descubrir
     * @return True si hay una casilla por descubrir y False si no la hay
     */
    bool hayMapaPorDescubrir();

    /**
     * @brief Reiniciar las variables de estado de la partida si el jugador muere
     */
    void reiniciar();

    /**
     * @brief Determina un giro aleatorio hacia izquierda o hacia derecha
     * @return Giro a izquierda o a derecha
     */
    Action girar();

    /**
     * @brief Determina las acciones ante diferentes situaciones para 
     *        rodear los muros del mapa
     * @param sensores Sensores
     */
    void rodearMuros(Sensores sensores);

    /**
     * @brief Determina las acciones ante diferentes situaciones para 
     *        evitar caer en los precipicios del mapa
     * @param sensores Sensores
     */
    void evitarPrecipicios(Sensores sensores);

    /**
     * @brief Determina las acciones para ir a una casilla específica
     *        vista en los sensores si necesita ir a ella
     * @param sensores Sensores
     */
    void irParaCiertaCasilla(Sensores sensores);

    /**
     * @brief Si el jugador gira 5 veces consecutivas sin avanzar,
     *        se considera que se ha quedado atascado en una casilla
     * @param sensores Sensores
     * @return True si el jugador está atascado en una casilla y False si no lo está
     */
    bool atascadoEnUnaCasilla(Sensores sensores);

    /**
     * @brief Indica si se observa algún aldeano en los sensores
     * @param sensores Sensores
     * @return True si hay un aldeano y False si no lo hay
     */
    bool hayAldeano(Sensores sensores);

    /**
     * @brief Indica si se observa algún lobo en los sensores
     * @param sensores Sensores
     * @return True si hay un lobo y False si no lo hay
     */
    bool hayLobo(Sensores sensores);

    /**
     * @brief Cuenta el número de casillas del mapa resultado no descubiertas,
     *        es decir, aquellas casillas que sean '?'
     * @return Número de casillas del mapa no descubiertas
     */
    int contarCasillasSinDescubrir();

    /**
     * @brief Dada una casilla (considerada la celda central de una matriz 3x3), 
     *        indica si hay alguna casilla a su alrededor (en la matriz 3x3)
     *        que esté descubierta, es decir, que sea diferente a '?'
     * @param f Fila en la que se encuentra la casilla
     * @param c Columna en la que se encuentra la casilla
     * @return True si hay alguna casilla descubierta alrededor y False si no la hay
     */
    bool casillaAlrededorDescubierta(int f, int c);

    /**
     * @brief Obtiene todas las casillas del mapa resultado que no estén descubiertas
     *        (iguales a '?') y que tengan a su alrededor una casilla descubierta
     *        (diferentes a '?')
     * @return Vector con la posición de las casillas no descubiertas del mapa resultado
     *         que tengan a su alrededor una casilla descubierta
     */
    vector<pair<int,int>> obtenerCasillasSinDescubrir();

    /**
     * @brief Dado un rango de búsqueda matricial, busca en dicha submatriz
     *        cuál es el tipo de casilla más repetida
     * @param ini_f Fila inicial de la submatriz 
     * @param fin_f Fila final de la submatriz 
     * @param ini_c Columna inicial de la submatriz 
     * @param fin_c Columna final de la submatriz 
     * @return Tipo de casilla más repetida
     */
    char casillaMasRepetida(int ini_f, int fin_f, int ini_c, int fin_c);

    /**
     * @brief Se infiere cada casilla no descubierta (igual a '?') del mapa resultado
     *        a partir de las casillas descubiertas a su alrededor (diferentes a '?')
     */
    void inferirMapaLocalmente();

    /**
     * @brief Se infieren todas las casillas no descubiertas (iguales a '?') del 
     *        mapa resultado  asignándoles la casilla descubierta (diferente a '?') 
     *        más repetida en todo el mapa resultado o el mapa auxiliar (si se ha
     *        descubierto algo en el mapa resultado se elige este, si no, se elige
     *        el mapa auxiliar)
     */
    void inferirMapaGlobalmente();

    /**
     * @brief Se elige si inferir el mapa resultado no descubierto (igual a '?') 
     *        localmente o globalmente en función del porcentaje de casillas no 
     *        descubiertas (iguales a '?') que haya en mapa resultado (si dicho 
     *        porcentaje es menor o igual que el 45%, es decir, se ha descubierto 
     *        al menos el 55% del mapa, entonces se aplica la inferencia local. 
     *        En otro caso, se aplica la inferencia global)
     */
    void inferirMapa();

  private:

    /***********************************************************/
    /****************** VARIABLES DE ESTADO ********************/
    /***********************************************************/

    int fil, col, brujula;
    bool girar_derecha;
    bool bien_situado;
    bool tengo_bikini, tengo_zapatillas;
    int num_giros_consecutivos;
    Action ultimaAccion;  
	  vector<Action> movimientos;
    char mapaAuxiliar[200][200];
};

#endif