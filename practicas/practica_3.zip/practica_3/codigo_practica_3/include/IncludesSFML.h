#ifndef __INCLUDESSFML_H__
#define __INCLUDESSFML_H__

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>

using namespace sf;


#endif